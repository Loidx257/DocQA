import json
from pathlib import Path
import zipfile
import pytest
from scripts.build_release import build


def source_tree(tmp_path):
    root=tmp_path/"source"
    root.mkdir()
    for name in (".gitignore","AGENTS.md","README.md","pyproject.toml","start.ps1"):
        (root/name).write_text("example",encoding="utf8")
    for folder in ("docqa","examples","scripts","tests","docs","data",".venv"):
        (root/folder).mkdir()
    for name in ("需求规格说明书.md","发布说明.md"):
        (root/"docs"/name).write_text("public documentation",encoding="utf8")
    cfg={"allow_remote_models":False,**{role:{"enabled":False,"base_url":"","url":"","model":""} for role in ("chat","vision","embedding","reranker","bge","visual_embedding")}}
    (root/"config.example.json").write_text(json.dumps(cfg),encoding="utf8")
    return root


def test_release_excludes_local_data_and_configuration(tmp_path):
    root=source_tree(tmp_path)
    (root/"config.json").write_text("private settings",encoding="utf8")
    (root/"data"/"conversation.sqlite3").write_bytes(b"private history")
    (root/".venv"/"secret.txt").write_text("private environment",encoding="utf8")
    (root/"docs"/"private.png").write_bytes(b"private screenshot")
    result=build(root,tmp_path/"release")
    with zipfile.ZipFile(result["archive"]) as archive:
        names=archive.namelist()
        assert "DocQA/config.example.json" in names
        assert not any("/data/" in name or "/.venv/" in name or name.endswith(("config.json","private.png")) for name in names)


def test_release_rejects_secret_in_source(tmp_path):
    root=source_tree(tmp_path)
    (root/"docqa"/"leak.py").write_text("sk-"+"x"*32,encoding="utf8")
    with pytest.raises(ValueError,match="密钥"):
        build(root,tmp_path/"release")


def test_release_requires_models_disabled_by_default(tmp_path):
    root=source_tree(tmp_path)
    cfg=json.loads((root/"config.example.json").read_text(encoding="utf8"))
    cfg["chat"]["enabled"]=True
    (root/"config.example.json").write_text(json.dumps(cfg),encoding="utf8")
    with pytest.raises(ValueError,match="关闭模型"):
        build(root,tmp_path/"release")
