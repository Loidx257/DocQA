# DocQA · 个人本地多模态文档智能问答

将 PDF、Word、PowerPoint、Markdown 和图片整理为个人知识库，通过自然语言提问并追溯原文。

发布版本不包含 API 密钥、账号凭证、个人文档、索引或会话记录。所有模型默认停用，使用者自行配置自己的 API。不配置模型时仍可导入文字资料、使用 BM25 检索和原文摘录。

## 启动

需要 Python 3.11 或更新版本。Windows PowerShell 在项目目录运行：

```powershell
.\start.ps1
```

脚本创建虚拟环境、安装依赖，并在首次运行时从 config.example.json 创建 config.json。也可手动启动：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e .
Copy-Item config.example.json config.json
.\.venv\Scripts\python.exe -m docqa serve
```

打开 <http://127.0.0.1:8765>。在“文档知识库”导入资料，在“智能问答”提问。Linux/macOS 使用 .venv/bin/python。首次安装依赖需要联网，页面资源本地提供。

## 填写自己的 API

编辑本机 config.json，填写需要的角色的 base_url、model，并设置 enabled 为 true。密钥通过环境变量读取，不写入配置文件或源码。

| 角色 | 能力 | 密钥环境变量 |
| --- | --- | --- |
| chat | 回答综合、流式输出 | DOCQA_CHAT_KEY |
| vision | 图片内容解读 | DOCQA_VISION_KEY |
| embedding | 文本语义检索 | DOCQA_EMBEDDING_KEY |
| reranker | 候选资料精排 | DOCQA_RERANKER_KEY |
| bge | 独立补充稠密向量 | DOCQA_BGE_KEY |
| visual_embedding | 文字查询图片 | DOCQA_VISUAL_EMBEDDING_KEY |

只启用需要的角色。Chat 配置结构示例（地址和模型需自行填写）：

```json
{
  "allow_remote_models": true,
  "chat": {
    "enabled": true,
    "base_url": "https://YOUR_PROVIDER/v1",
    "model": "YOUR_CHAT_MODEL",
    "api_key_env": "DOCQA_CHAT_KEY",
    "timeout": 120
  }
}
```

将这些字段合并到已有配置，其他角色保持原样。base_url 自动补充接口路径；也可以填写完整 url，其优先级高于 base_url。同一服务的不同角色可使用相同环境变量名。

在启动服务的终端设置自己的密钥（下例需要 PowerShell 7）：

```powershell
$env:DOCQA_CHAT_KEY = Read-Host '输入你自己的 Chat API 密钥' -MaskInput
.\.venv\Scripts\python.exe -m docqa doctor --role chat
.\.venv\Scripts\python.exe -m docqa serve
```

Windows 也可以使用当前用户加密凭证，交互输入不回显：

```powershell
.\.venv\Scripts\python.exe -m docqa credential-set my-chat
```

随后在 chat 中增加 `"api_key_store": "my-chat"`。密文仅属于使用者自己的 Windows 用户；环境变量优先。其他系统使用环境变量。项目不会自动加载 .env 文件。

修改文件配置后重启服务。远程模型需要显式设置 allow_remote_models 为 true，届时相关证据片段或图片会发送至所配置服务。是否收费以服务商规则为准，本项目不会充值或购买资源。

## 接口兼容与升级

Chat/Vision 使用兼容 /chat/completions 的接口；流式回答要求 Chat 支持 SSE。向量使用 /embeddings；精排使用 /rerank。图文模型还需支持 `[{"text":"..."}]` 和 `[{"image":"Base64..."}]` 输入，不能只按模型名称判断兼容。

以下是公开厂商/模型的格式示例，没有账号信息，需要自行确认可用性、设置密钥环境变量并启用远程调用：

- config.gitee.example.json：厂商接口示例，默认停用。
- config.retrieval.example.json：文本向量与精排升级参数。
- config.bge.example.json：补充稠密向量升级参数。
- config.visual.example.json：图文检索升级参数。

服务状态页可配置文本向量和精排。输入的密钥在 Windows 当前用户下加密保存。验证接口并完成临时索引后才切换，失败保留旧索引。

```powershell
python -m docqa doctor
python -m docqa setup-retrieval config.retrieval.example.json
python -m docqa setup-bge config.bge.example.json
python -m docqa setup-visual config.visual.example.json
```

CLI 升级参数可能使用与主配置不同的环境变量名，应按所用文件设置。先在 config.json 中显式启用远程调用。模型、解析或分块配置变更后可能需要重建。

BGE 云端 /embeddings 通道是稠密向量，不能当作学习型稀疏向量。本地稀疏通道需安装 `.[sparse]`、自行准备真实 BGE-M3 目录并配置 sparse_model_path，不自动下载模型。

## 主要能力

- 解析保留真实页码、标题、图片与来源；Word 使用标题，PPT 原生组合图形建议先导出 PDF。
- 按实际配置启用 BM25、语义、补充向量、图文召回，经 RRF 融合并可选精排。未配置或调用失败会明确提示。
- 回答和来源支持 Markdown，Mermaid 支持源码、SVG 下载及放大。引用编号检查不能代替人工事实核对。
- PDF 引用直接预览原文页并精确匹配高亮；图表解读或无法匹配的片段只定位页。
- 真正流式回答、停止生成、重新回答；未完成内容明确标记，不作为后续事实依据。
- 本地会话历史可恢复、切换、删除；追问参考最近四轮，仍重新检索和引用。
- 支持分类、目录监控、增量更新及人工标注的检索评测。

## 常用命令

```powershell
python -m docqa build examples --category 示例
python -m docqa query "混合检索如何工作？"
python -m docqa ask "混合检索如何工作？"
python -m docqa list
python -m docqa rebuild
python -m docqa refresh-images
python -m docqa compare examples/evaluation/cases.json --out comparison.json
```

评测应与实际导入资料和真值标注匹配，示例结果不证明真实文档上的通用准确率。

## 开发和发布

```powershell
python -m pip install -e ".[test,ui-test]"
python -m pytest -q
```

scripts/verify_*_ui.py 验证页面交互，需要安装 Chrome。部分脚本使用临时知识库及本地替换模型响应，不代表云端模型效果。

数据默认存储于 data/，会话位于 data/conversations.sqlite3；Windows 凭证密文存于项目外的当前用户目录。config.json、.env、凭证、数据、虚拟环境、缓存和日志不应上传。对外分享使用干净源码包，私密备份不要上传。

服务仅绑定本机回环地址，面向个人使用，不具备公开互联网多用户部署所需的账户权限隔离。
