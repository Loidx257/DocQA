"""Small opt-in model probes. Never inspect or persist raw API keys."""
import base64
import io
from .models import configured, endpoint_url, embeddings, bge_embeddings, visual_embeddings, rerank, chat, ModelError


def diagnose(cfg, roles=None):
    output = []
    for role in roles or ("chat", "vision", "embedding", "reranker", "bge", "visual_embedding"):
        item = {"role": role, "status": "disabled", "message": "未配置或已停用，未发送请求"}
        if not configured(cfg, role):
            output.append(item)
            continue
        try:
            if role == "visual_embedding":
                from PIL import Image, ImageDraw
                vectors = []
                for color in ("red", "blue"):
                    raw = io.BytesIO()
                    image = Image.new("RGB", (128,128), "white")
                    draw = ImageDraw.Draw(image)
                    if color == "red":
                        draw.ellipse((16,16,112,112), fill=color)
                    else:
                        draw.rectangle((16,16,112,112), fill=color)
                    image.save(raw, format="PNG")
                    vectors.extend(visual_embeddings(cfg, [{"image": base64.b64encode(raw.getvalue()).decode()}]))
                if vectors[0] == vectors[1]:
                    raise ModelError("invalid_response", "不同测试图片返回相同向量，图文检索未通过有效性验证")
                visual_embeddings(cfg, [{"text": "red circle"}])
                item["dimension"] = len(vectors[0])
            elif role in {"embedding","bge"}:
                vector = (bge_embeddings if role == "bge" else embeddings)(cfg, ["DocQA connection test"])[0]
                item["dimension"] = len(vector)
            elif role == "reranker":
                rerank(cfg, "connection test", ["connection test", "unrelated"])
            elif role == "vision":
                from PIL import Image
                raw = io.BytesIO()
                Image.new("RGB", (32,32), "white").save(raw, format="PNG")
                data = "data:image/png;base64," + base64.b64encode(raw.getvalue()).decode()
                chat(cfg, role, [{"role":"user", "content":[{"type":"text","text":"Describe the image briefly."}, {"type":"image_url","image_url":{"url":data}}]}])
            else:
                chat(cfg, role, [{"role":"user", "content":"Reply OK."}])
            item.update(status="available", message="该模型接口已通过最小请求验证；仅证明此模型当前可调用")
        except ModelError as exc:
            item.update(status=exc.status, message=str(exc))
        except Exception:
            item.update(status="unavailable", message="配置、服务响应或模型格式不兼容，未启用")
        output.append(item)
    return {"models": output, "note":"401可能表示凭证无效或过期；403也可能是权限限制，不能仅据此断定密钥无效。诊断不修改配置，不发送用户文档。"}
