"""Bounded model work and reusable successful inference results during import."""
from concurrent.futures import ThreadPoolExecutor
from collections import deque
from contextlib import closing
import hashlib
import json
from pathlib import Path
import sqlite3
from .models import endpoint_url, ModelError


def notify(cfg, stage, done=0, total=0):
    callback = cfg.get("_ingest_progress")
    if callback:
        callback(stage, done, total)


def ordered_work(items, call):
    """Keep at most two tasks in flight; never queue a whole failed document."""
    iterator = iter(items)
    pool = ThreadPoolExecutor(max_workers=2)
    pending = deque()
    try:
        for _ in range(2):
            try:
                pending.append(pool.submit(call, next(iterator)))
            except StopIteration:
                break
        while pending:
            yield pending.popleft().result()
            try:
                pending.append(pool.submit(call, next(iterator)))
            except StopIteration:
                pass
    finally:
        for future in pending:
            future.cancel()
        pool.shutdown(wait=True, cancel_futures=True)


def cached_call(cfg, role, payload, call):
    endpoint = cfg.get(role, {})
    identity = [2, role, endpoint_url(cfg, role), endpoint.get("model"),
                endpoint.get("dimensions"), endpoint.get("request_options"), payload]
    key = hashlib.sha256(json.dumps(identity, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    root = Path(cfg.get("data_dir", "data"))
    root.mkdir(parents=True, exist_ok=True)
    path = root / "ingest-cache.sqlite3"
    # Each worker owns its connections; no DB lock is held over a network call.
    with closing(sqlite3.connect(path, timeout=30)) as db, db:
        db.execute("CREATE TABLE IF NOT EXISTS results(key TEXT PRIMARY KEY, value TEXT)")
        found = db.execute("SELECT value FROM results WHERE key=?", (key,)).fetchone()
    if found and not cfg.get("_ingest_cache_bypass"):
        try:
            return json.loads(found[0])
        except (ValueError, TypeError):
            pass
    value = call()
    with closing(sqlite3.connect(path, timeout=30)) as db, db:
        db.execute("INSERT OR REPLACE INTO results VALUES(?,?)", (key, json.dumps(value, ensure_ascii=False)))
    return value


def text_vectors(cfg, role, texts, call):
    """Small batches, two workers, one retry for transient errors, stable ordering."""
    batches = [texts[i:i+8] for i in range(0, len(texts), 8)]
    label = "Qwen 文本向量" if role == "embedding" else "BGE-M3 补充向量"
    notify(cfg, label, 0, len(texts))
    def run(batch):
        def request():
            for attempt in range(2):
                try:
                    return call(cfg, batch)
                except ModelError as exc:
                    if attempt or exc.status not in {"timeout", "unreachable", "service_unavailable"}:
                        raise
                    notify(cfg, label + "：连接暂时失败，重试一次")
        return cached_call(cfg, role, batch, request)
    vectors = []
    for result in ordered_work(batches, run):
        vectors.extend(result)
        notify(cfg, label, len(vectors), len(texts))
    return vectors
